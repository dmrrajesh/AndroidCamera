package info.androidhive.androidcamera;

import android.app.Application;

/**
 * Created by Rajesh Saini on 27-Jul-18.
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }

}
